//
//  MyAppDelegate.h
//
//

#import <Foundation/Foundation.h>
#import "WLCordovaAppDelegate.h"

@interface MyAppDelegate : WLCordovaAppDelegate {

}

@end
